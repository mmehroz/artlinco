@extends('layout.teacherheader.teacherheader')
@section('content')
<style>
button:active {
    border:none !important;
    border-style:none !important;
}
    .quizaddbtn{
        background: #043740;
    color: #fff;
    border-color: #043740;
    border-radius: 6px;
    }
    .quizaddbtn:hover{
        color:yellow;
    }
    .quizremovebtn{
         background: red;
    color: #fff;
    border-color: red;
    border-radius: 6px;
    }
    .quizquestion{
        width: 35%;
    background: #043740;
    border: 1px solid #043740;
    border-radius: 9px;
    padding: 15px;
    color: yellow;
    }
    
    .quizmultiupload{
        width:19%;
    }
</style>
<link rel="stylesheet" type="text/css" href="{!! asset('public/css/teachercss/question.css') !!}">
        <!--Main layout-->
        <main class="mains">
            <div class="container" style="margin-top:290px">
                <form onsubmit="return false" class="" style="width: 100%;">
<h2 style="color:#043740;font-weight:bold">Quiz</h2>


<div class="fields_wrappers mt-5">
    <div>
        <input type="text" class="quizquestion" placeholder="Write Your Question" name="field_name[]" value=""/>
        <input type="file" class="quizmultiupload" id="files" name="files" multiple>
        <a href="javascript:void(0);" class="add_btns" title="Add field"><button class="quizaddbtn">Add Field</button></a>
    </div>
</div>
                    <div class="text-left">
                        <button
                            class="materialbtn submitbtn btn  mt-4"
                            onclick="myFunn()"
                        >
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </main>
        <!--Main layout-->

@endsection
