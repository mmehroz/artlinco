@extends('layout.adminheader.adminheader')
@section('content')
<link rel="stylesheet" type="text/css" href="{!! asset('public/css/admincss/index.css') !!}">
  <!--Main layout-->
  <main class="mains">
    <div class="container d-flex align-items-center justify-content-center text-center" style="margin-top: 190px;">
        @if(session('message'))
            <div><p class="alert alert-info mt-3" >{{session('message')}}</p> </div>
          @endif
          @if ($errors->any())
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                  <div><h4><li>{{ $error }}</li></h4> </div>
                @endforeach
              </ul>
            </div>
          @endif
      <div class="text-white mt-5" style="width: 100%;">
        <a href="{{url('/userlist')}}">  <button for="actual-btn" class="btn materialbtn">User Registration</button></a>
       <button for="actual-btn" class="btn materialbtn userstatisbtn">User Statistics</button>
        <div class=" justify-content-center secondbtnrow">
       <a href="{{url('/quizmanage')}}"><button for="actual-btn" class="btn materialbtn ">Quiz Manager</button></a>
       <a href="{{url('/teacherstats')}}"><button for="actual-btn" class="btn materialbtn userstatisbtn">Dashboard</button></a>
        </div>
        <div class=" justify-content-center secondbtnrow">
          <a href="{{url('/testquestions')}}"> <button for="actual-btn" class="btn materialbtn">Personality Database</button></a>
         <!-- <button for="actual-btn" class="btn materialbtn userstatisbtn">Test Questions</button> -->
         <a href="{{url('/testquestions')}}"> <button for="actual-btn" class="btn materialbtn">Test Questions</button></a>
          </div>
      </div>

    </div>
  </main>
  <!--Main layout-->

  @endsection