@extends('layout.adminheader.adminheader')
@section('content')
<link rel="stylesheet" type="text/css" href="{{ asset('/public/css/admincss/quizmanage.css') }}"></link>
  <!--Main layout-->
  <main class="mains">

      <div class="container align-items-center justify-content-center text-center" style="margin-top: 190px;">
        <div class="row">
          <div class="col-md-12">
          <div class="table-wrap">
               <h2 style="font-weight: bold;text-align:left">QUIZ'S LIST</h2>
          <table class="table mytable">
          <thead class="thead-primary">
          <tr class="theadrow-primary">
          <th>ID</th>
          <th>Teacher Name</th>
          <th>Class Name</th>
          <th>Quiz Start Date</th>
          <th>View Quiz</th>
          </tr>
          </thead>
          <tbody>
          <tr>
          <th scope="row" class="scope">1</th>
          <td>Roger</td>
          <td>7 Standard</td>
          <td>09/1/2022</td>
          <td><a href="{{url('/quizmanage/viewquiz/1')}}" class="btn editbtn">View Quiz</a></td>
          </tr>
          <tr>
              <th scope="row" class="scope">2</th>
              <td>Peter</td>
              <td>10 Standard</td>
              <td>13/2/2022</td>
              <td><a href="{{url('/quizmanage/viewquiz/2')}}" class="btn editbtn">View Quiz</a></td>
              </tr>
              <tr>
                  <th scope="row" class="scope">3</th>
                  <td>Sam</td>
                  <td>5 Standard</td>
                  <td>01/3/2022</td>
                  <td><a href="{{url('/quizmanage/viewquiz/3')}}" class="btn editbtn">View Quiz</a></td>
                  </tr>
                  <tr>
                      <th scope="row" class="scope">4</th>
                      <td>Fedrick</td>
                      <td>9 Standard</td>
                      <td>07/4/2022</td>
                      <td><a href="{{url('/quizmanage/viewquiz/4')}}" class="btn editbtn">View Quiz</a></td>
                      </tr>
                      <tr>
                          <th scope="row" class="scope">5</th>
                          <td>Edward</td>
                          <td>6 Standard</td>
                          <td>022/5/2022</td>
                          <td><a href="{{url('/quizmanage/viewquiz/5')}}" class="btn editbtn">View Quiz</a></td>
                          </tr>
                          <tr>
                              <th scope="row" class="scope">6</th>
                              <td>Peter</td>
                              <td>2 Standard</td>
                              <td>016/6/2022</td>
                              <td><a href="{{url('/quizmanage/viewquiz/6')}}" class="btn editbtn">View Quiz</a></td>
                              </tr>
          </tbody>
          </table>
          </div>
          </div>
          </div>
      </div>
  </main>
  <!--Main layout-->
  @endsection