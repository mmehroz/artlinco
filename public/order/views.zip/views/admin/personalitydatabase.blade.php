@extends('layout.adminheader.adminheader')
@section('content')
<link rel="stylesheet" type="text/css" href="{!! asset('public/css/admincss/personalitydb.css') !!}">
  <!--Main layout-->
  <main class="mains">
    <div class="container align-items-center justify-content-center text-center" style="margin-top: 90px;">
        <div class="row" id="newpost">
          <div class="col-md-12">
          <div class="table-wrap">
          <table class="table mytable">
          <thead class="thead-primary">
            <tr class="theadrow-primary">
              <th>Test Title</th>
              <th>No of Questions</th>
              <th>No of Correct Answers</th>
              <th>No of Wrong Answers</th>
            </tr>
          </thead>
          <tbody>
            @foreach($data as $val)
            <tr>
              <td>{{$val->test_title}}</td>
              <?php
                $noofquestions = $task = DB::table('testquestions')
                ->where('test_id','=',$val->test_id)
                ->select('test_id')
                ->count();
                $noofanswers = $task = DB::table('testanswers')
                ->where('test_id','=',$val->test_id)
                ->select('test_id')
                ->count();
                $noofwronganswers = $noofquestions-$noofanswers;
              ?>
              <td>{{$noofquestions}}</td>
              <td>{{$noofanswers}}</td>
              <td>{{$noofwronganswers}}</td>
            </tr>
            @endforeach
          </tbody>
          </table>
          </div>
          </div>
          </div>
      </div>
  </main>
  @endsection