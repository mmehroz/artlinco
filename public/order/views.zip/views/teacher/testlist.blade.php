@extends('layout.teacherheader.teacherheader')
@section('content')
<link rel="stylesheet" type="text/css" href="{!! asset('public/css/teachercss/testlist.css') !!}">
<div class="container align-items-center justify-content-center text-center" style="margin-top: 190px;">
        <div class="row">
          <div class="col-md-12">
          <div class="table-wrap">
          <h2 style="font-weight: bold;text-align:left">TEST'S LIST</h2>
          <button class="btn materialbtn addstudentbtn"><a href="{{url('/createtest')}}">Create Test</a></button>
          <table class="table mytable">
          <thead class="thead-primary">
          <tr class="theadrow-primary">
          <th>ID</th>
          <th>Test Title</th>
          <th>Test Duration</th>
          <th>Test Date</th>
          <th>No of Questions</th>
          <th>Edit</th>
          <th>View</th>
          <th>Delete</th>
          </tr>
          </thead>
          <tbody>
          <tr>
          <th scope="row" class="scope">1</th>
          <td>Test #1</td>
          <td>1 hour</td>
          <td>9/23/22</td>
          <td>10</td>
          <td><a href="" class="btn editbtn">Edit</a></td>
          <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
          <td><a href="" class="btn btn-danger">Delete</a></td>
          </tr>
          <tr>
            <th scope="row" class="scope">2</th>
            <td>Test #2</td>
            <td>1 hour</td>
            <td>9/23/22</td>
            <td>10</td>
            <td><a href="" class="btn editbtn">Edit</a></td>
            <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
            <td><a href="" class="btn btn-danger">Delete</a></td>
            </tr>
            <tr>
                <th scope="row" class="scope">3</th>
                <td>Test #3</td>
                <td>1 hour</td>
                <td>9/23/22</td>
                <td>10</td>
                <td><a href="" class="btn editbtn">Edit</a></td>
                <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
                <td><a href="" class="btn btn-danger">Delete</a></td>
                </tr>
                <tr>
                    <th scope="row" class="scope">4</th>
                    <td>Test #4</td>
                    <td>1 hour</td>
                    <td>9/23/22</td>
                    <td>10</td>
                    <td><a href="" class="btn editbtn">Edit</a></td>
                    <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
                    <td><a href="" class="btn btn-danger">Delete</a></td>
                    </tr>
                    <tr>
                        <th scope="row" class="scope">5</th>
                        <td>Test #5</td>
                        <td>1 hour</td>
                        <td>9/23/22</td>
                        <td>10</td>
                        <td><a href="" class="btn editbtn">Edit</a></td>
                        <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
                        <td><a href="" class="btn  btn-danger">Delete</a></td>
                        </tr>
                        <tr>
                            <th scope="row" class="scope">6</th>
                            <td>Test #6</td>
                            <td>1 hour</td>
                            <td>9/23/22</td>
                            <td>10</td>
                            <td><a href="" class="btn editbtn">Edit</a></td>
                            <td><a href="{{url('/testview')}}" class="btn btn-success">View</a></td>
                            <td><a href="" class="btn btn-danger">Delete</a></td>
                            </tr>
          </tbody>
          </table>
          </div>
          </div>
          </div>
      </div>
      @endsection