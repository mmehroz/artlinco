@extends('layout.std.std') @section('content')
<link
    rel="stylesheet"
    type="text/css"
    href="{!! asset('public/css/studentcss/index.css') !!}"
/>
<style>
  .submitbtn{
    background: #043740;
    border-color: #043740;
    color: #fff;
  }
  .submitbtn:hover{
    background: #043740;
    color: yellow;
  }
  .checkbtn{
      margin-right: 8px !important;
  }
  @media (max-width: 480px) {
    .questionheading{
        padding-left: 85px;
    }
    .inputbtn{
      width: 80%;
      margin-top: 10px;
      margin-left: 5px;
    }
    .checkbtn{
      margin-right: 0px !important;
margin-left: 15px;
    }
    .submitbtn{
    transform: translateX(31px);
    }
    .swiper-button-prev, .swiper-rtl .swiper-button-next {
   left: 13% !important;
    right: auto !important;
}
.swiper-button-next, .swiper-rtl .swiper-button-prev {
   right: 13% !important;
    left: auto !important;
}
    .swiper-button-next, .swiper-button-prev {
    top: 71% !important;
}
    .swiper-wrapper{
      margin-top: 20px;
    }
  }
</style>
<main class="mains">
    <div class="container" style="margin-top: 310px">
        <div class="swiper-container-wrapper">
            <div class="swiper-container gallery-thumbs">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                       <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Personality Test</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#1</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#2</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#3</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#4</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#5</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <h5 style="color: #043740;font-weight: bold;">Question#6</h5>
                        </div>
                    </div>
                    <div class="swiper-slide">
                      <div class="row">
                          <h5 style="color: #043740;font-weight: bold;">Thankyou</h5>
                      </div>
                  </div>
                </div>
            </div>
            <!-- Slider main container -->
            <div class="swiper-container gallery-top">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <div class="swiper-slide">
                        <div class="title" style="font-size:45px;color: #043740;font-weight: bold;">Please Give Personality Test</div>
                        <div class="description">
                            </div>
                            </div>
                   
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 1</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                            <div class="row mt-5">
                              
                             </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 2</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                            <div class="row mt-5">
                              
                             </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 3</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                            <div class="row mt-5">
                              
                             </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 4</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                            <div class="row mt-5">
                              
                             </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 5</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                            <div class="row mt-5">
                              
                             </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="title" style="color: #043740;font-weight: bold;">Question 6</div>
                        <div class="description">
                            <div class="row mt-3">
                                <h6 class="questionheading">Who is The President of USA?</h6>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="George Bush"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Donald Trump"
                                    />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Bill Clinton"
                                    />
                                </div>
                                <div class="col-12 col-lg-6 d-flex">
                                    <input
                                        type="checkbox"
                                        class="checkbtn"

                                    />
                                    <input
                                        type="text"
                                        class="form-control inputbtn"
                                        value="Joe Biden"
                                    />
                                </div>
                            </div>
                           <div class="row mt-5">
                            <button class="btn submitbtn">Submit</button>
                           </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                      <div class="title" style="color: #043740;font-weight:bold;">Thankyou For Attempting Test</div>
                      <div class="description">
                        </div>
                        </div>
                        </div>
                </div>
                <!-- Add Arrows -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
            <!-- Slider thumbnail container -->
        </div>
    </div>
    <!-- Slider main wrapper -->
</main>
@endsection
