@extends('layout.studentheader.apptheme')
@extends('layout.studentheader.mainheader')
@section('content')

        <!-- Sign Up Start -->
        <!-- Content Start -->

        <div class="container mt-5">
            <div class="row mt-5">
                <div class="col-lg-1"><i class='fas fa-greater-than' style='font-size:18px;color: #3E9499;'></i></div>
                <div class="col-lg-4">
                <div class="progress-title" style="color:#3E9499;font-weight: 700;">O-ABENHED</div></div>
                <div class="col-lg-7">
              <input type="range" min="1" max="100" value="50" class="slider1" id="myRange">
              </div>

                </div>
                </div>




    @endsection
