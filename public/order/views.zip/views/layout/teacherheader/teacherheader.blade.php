<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Artlinco</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <!-- Google Fonts Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="css/mdb.min.css" /> -->
    <!-- Custom styles -->
    <!-- <link rel="stylesheet" href="css/style.css" /> -->
</head>
<body >
      <!--Main Navigation-->
  <header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
         <a class="navbar-brand logo-img" style="width: 15%;" href="{{url('/')}}">
         <img src="{!! asset('public/images/logo.svg') !!}" width="100%" class="d-inline-block align-top" alt="">
        </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
   <li class="nav-item">
              <a class="nav-link" href="{{ url('/studentlist') }}" style="color:#043740 !important;font-weight: 600;">
                Student List
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ url('/testlist') }}" style="color:#043740 !important;font-weight: 600;">
                Test List
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#"  style="color: #212529 !important;
    font-weight: 600;">
    {{session()->get('firstname')}}
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#">
                  <img src="{!! asset('public/images/womenavatar.png') !!}" class="d-inline-block align-top logoimg" style="  width: 35px;
  height: 35px;
  border-radius: 50%;transform: translateX(-13px) translateY(-5px);" alt="">
              </a>
            </li>
    </ul>
  </div>
</nav>
    <!-- Navbar -->

    <!-- Background image -->

    <!-- Background image -->
  </header>

  @yield('content')

    <!--Footer-->
    <footer class="text-lg-start" style="background: #FCF176;">
    <!-- Copyright -->
    <div class="text-right p-3">
      <a class="text-dark" href=""M> <img src="{!! asset('public/images/footerlogo.svg') !!}" width="14%" class="d-inline-block align-top footer-logo-img" alt=""></a>
    </div>
    <!-- Copyright -->
  </footer>
  <!--Footer-->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script>
      const actualBtn = document.getElementById("actual-btn");
      const fileChosen = document.getElementById("file-chosen");
      actualBtn.addEventListener("change", function(){
        fileChosen.textContent = this.files[0].name
      })
      const actualBtn1 = document.getElementById("actual-btn1");
      const fileChosen1 = document.getElementById("file-chosen1");
      actualBtn1.addEventListener("change", function(){
        fileChosen1.textContent = this.files[0].name
      })
      const actualBtn2 = document.getElementById("actual-btn2");
      const fileChosen2 = document.getElementById("file-chosen2");
      actualBtn2.addEventListener("change", function(){
        fileChosen2.textContent = this.files[0].name
      })
      </script>
<script type="text/javascript">
                      function myFunctions() {
                        window.location.href="{{ url('/testlist') }}";
          }
          var fieldName = `0*field_name-0`;
          var parseNum = 0;
           var qNum = 0;
          
            $(document).ready(function () {
                var maxField = 1000; //Input fields increment limitation
                var addButton = $(".add_button"); //Add button selector
                var wrapper = $(".field_wrapper"); //Input field wrapper
                const innerWrapper = $(".inner_field");
                const addAnswerBtn = ".add_answer";
               
           
                var x = 1; //Initial field counter is 1
              
                //Once add button is clicked

                $(addButton).click(function () {
                     var fieldHTML =
                  '<div class="inner_field begi mt-3"><input type="text" class="materialbtn inputwidth" placeholder="Write Question" name="question_name[]"value="" /><input type="text"  class="materialbtn inputwidth answer_field editanswersa " placeholder="Write Answer" name="staticanswer_name[]"value="" /><button style="margin-left:10px" class="add_answer" title="Add Answer">Add Answer</button><a href="javascript:void(0);" style="margin-left:5px" class="remove_button" title="Remove"><button class="remove_field" style="color:red;cursor:pointer">Remove</button></a></div>'; //New input field html
                    qNum = parseInt(fieldName.split('*')[0]);
                    qNum = qNum + 1;
                    fieldName = `${qNum}*field_name-0`;
                  console.log(fieldName);
                  console.log("test");
                    //Check maximum number of input fields
                    if (x < maxField) {
                        x++; //Increment field counter
                        $(wrapper).append(fieldHTML); //Add field html
                    }
                });

                $(wrapper).on("click", ".add_answer", function (e) {
                    e.preventDefault();
                    const answerField = `<div class="asnwer_wrapper mt-2"><input type="text"  class="materialbtn inputwidth answer_field added_answer_field" placeholder="Write Answer" name="${fieldName}"
                value="" /><input class="answeradio" type="checkbox" value="correctanswer"> <button class=" remove_answer addedansweremove" title="Remove">Remove</button><div>`;
                   
                    $(this).parent(".inner_field").append(answerField);
                    
                    parseNum = parseInt(fieldName.split('-')[1]);
                    console.log("parse Int: ", parseNum);
                    parseNum = parseNum + 1;
                    console.log("incremented Parsed: ", parseNum);
                    fieldName = `${qNum}*field_name-${parseNum}`;
                });

                $(wrapper).on("click", ".remove_answer", function (e) {
                    e.preventDefault();
                    $(this).parent(".asnwer_wrapper").remove();
                });

                //Once remove button is clicked
                $(wrapper).on("click", ".remove_button", function (e) {
                    e.preventDefault();
                    $(this).parent("div").remove(); //Remove field html
                    x--; //Decrement field counter
                });

            });
        </script>
        <script type="text/javascript">
$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_btns'); //Add button selector
    var wrappeersr = $('.fields_wrappers'); //Input field wrapper
    var fieldssHTML = '<div class="mt-3"><input type="text" name="field_name[]" class="quizquestion" placeholder="Write Your Question" value=""/><input type="file" id="files" class="quizmultiupload ml-1" name="files" multiple><a href="javascript:void(0);" class="removess_buttonss"><button class="quizremovebtn">Remove Field</button></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrappeersr).append(fieldssHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrappeersr).on('click', '.removess_buttonss', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>
