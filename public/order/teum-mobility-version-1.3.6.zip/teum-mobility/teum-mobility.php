<?php
/**
 * Plugin Name: Pareteum Mobility
 * Plugin URI: https://pareteum.com/
 * Description: Integration with Pareteum Mobility Services
 * Version: 1.3.6
 * Author: Pareteum
 * Author URI: https://pareteum.com/
 * Text Domain: Pareteum
 * @package Pareteum
 */

defined( 'ABSPATH' ) || exit;

// TEUM Utilities
require_once ('includes/teum-utilities.php');

// Mobility API
require_once ('includes/mobility.php');

// Settings
require_once ('mobility-settings.php');

// Set stuff up here

if ( is_admin() ) {
    $teum_settings_page = new TeumSettings();
}

if (class_exists('PareteumMobility')) {
    $pareteumMobility = new PareteumMobility();
}


class PareteumMobility {

	private $mobilityApi = NULL;

	public function __construct() {
		// WordPress Actions
		// add_action("wp_ajax_teum_ajax", array($this, "ajax_handler"));
		// add_action("wp_ajax_nopriv_teum_ajax", array($this, "no_priv_ajax"));
		add_action('init', array($this, "setup_scripts"));
	    add_action('init', array($this, 'add_my_account_endpoint'));
        add_action('woocommerce_account_activations_endpoint', array($this, 'activations_endpoint_content'));
        add_action('woocommerce_account_pareteum_dashboard', array($this, 'pareteum_dashboard_content'));

		// Filters
	    add_filter( 'woocommerce_account_menu_items', array($this, 'account_menu_items'), 1, 1);

		// Get the parameters for the mobility API
		$options = get_option( 'pareteum_mobility_options' );

		// Create the API object
		if (!$this->mobilityApi) {
			$this->mobilityApi = new Mobility();
		}

        // Add code to display the user's Pareteum account (aka subscriber) ID
        add_action('edit_user_profile', array($this, 'pareteum_user_profile_fields'));
        add_action('edit_user_profile_update', array($this, 'pareteum_save_user_profile_fields'));
        add_action('show_user_profile', array($this, 'pareteum_user_profile_fields'));
	}

    function pareteum_user_profile_fields($user)  {
        error_log("pareteum_user_profile_fields for ".print_r($user, true));
        $subscriberId = get_user_meta($user->ID, 'pareteum_subscriber_id', true);
        if ($subscriberId === false) {
            $subscriberId = '';
        }
        echo '<h3 class="heading">Pareteum Information</h3>';
        ?>
        <table class="form-table">
    	<tr>
                <th><label for="pareteum-customer-number">Customer Number</label></th>
    	        <td><input type="text" class="input-text form-control" name="pareteum-customer-number" id="pareteum-customer-number" value="<?=$subscriberId?>"/></td>
    	</tr>
        </table>
        <?php
    }

    function pareteum_save_user_profile_fields($user_id) {
        $custom_data = $_POST['pareteum-customer-number'];
        update_user_meta( $user_id, 'pareteum_subscriber_id', $custom_data );
    }


	function setup_scripts() {
		wp_register_script( "teum_mobility_script", WP_PLUGIN_URL.'/teum-mobility/js/mobility.js', array('jquery') );
		wp_localize_script( 'teum_mobility_script', 'teum_ajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'teum_mobility_script' );
	}

	// WooCommerce accounts menu items
	function account_menu_items($items) {
        //$items['activations'] = __( "Pareteum", 'pareteum');
        $items['subscriptions'] = __('Plans', 'pareteum');
        return $items;
    }

    function add_my_account_endpoint() {
        add_rewrite_endpoint('activations', EP_PAGES);
    }

    function pareteum_dashboard_content() {
    	wc_get_template( 'dashboard.php', array(), '', plugin_dir_path( __FILE__ ) . 'templates/' );
    }

    function _show_error($message) {
        wc_get_template( 'error.php', array('Message' => $message), '', plugin_dir_path( __FILE__ ) . 'templates/');
    }

    function _show_success($message) {
        wc_get_template( 'success.php', array('Message' => $message), '', plugin_dir_path( __FILE__ ) . 'templates/');
    }

    function _create_subscriber($currentUser) {
        $subscriber_info = array(
            "firstName" => sanitize_text_field($_POST['first_name']),
            "lastName" => sanitize_text_field($_POST['last_name']),
            "address" => array(
                "streetAddress" => sanitize_text_field($_POST['street_address']),
                "addressLine2" => sanitize_text_field($_POST['address_line2']),
                "city" => sanitize_text_field($_POST['city']),
                "state" => sanitize_text_field($_POST['state']),
                "zipCode" => sanitize_text_field($_POST['postcode'])
            ),
            "email" => sanitize_email($_POST['email']),
            "contactNumber" => sanitize_text_field($_POST['contact_phone'])
        );

        error_log("TEUM: New subscriber info: " . print_r($subscriber_info, true));

        $result = $this->mobilityApi->addSubscriber($subscriber_info);

        error_log("TEUM: addSubscriber result => " . print_r($result, true));

        if ($result['resultType'] == 'Success') {
            $subscriberId = $result['results'][0]['id'];
            error_log("TEUM: New Subscriber ID => " . $subscriberId);
            if (add_user_meta($currentUser->ID, 'pareteum_subscriber_id', $subscriberId, true) === false) {
                error_log("TEUM: Error adding the subscriber ID to the user meta data");
                return false;
            }
        } else {
            error_log("TEUM: Failed to add subscriber to backend DB: " . $result['messages'][0]);
            return false;
        }
        return $subscriberId;
    }

    function _setup_subscriber($subscriberId) {
        /*
         * @param array $subscriber {
         *      @var string $firstName Subscriber's first name
         *      @var string $lastName Subscriber's last name
         *      @var array $address {
         *          @var string $streetAddress First line of subscriber's address
         *          @var string $addressLine2 Second line of subscriber's address (optional)
         *          @var string $city Subscriber's city
         *          @var string $state Subscriber's state
         *          @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
         *      }
         *      @var string $email Email address for the subscriber (optional)
         *      @var string $contactNumber Contact phone number for the subscriber (optional)
         *      @var int $subscriberId Account number of the subscriber to connect this subscription to
         * }
         */

        $subscriber = array(
            "firstName" => sanitize_text_field($_POST['first_name']),
            "lastName" => sanitize_text_field($_POST['last_name']),
            "address" => array(
                "streetAddress" => sanitize_text_field($_POST['street_address']),
                "addressLine2" => sanitize_text_field($_POST['address_line2']),
                "city" => sanitize_text_field($_POST['city']),
                "state" => sanitize_text_field($_POST['state']),
                "zipCode" => sanitize_text_field($_POST['postcode'])
            ),
            "email" => sanitize_email($_POST['email']),
            "contactNumber" => sanitize_text_field($_POST['contact_phone']),
            "subscriberId" => intval($subscriberId)
        );
        return $subscriber;
    }

    function _setup_service($order_id, $phonenumber) {
        /*
         * @param array $service {
         *      @var array characteristics {}
         *          @var string $serviceZipCode
         *          @var string IMEI
         *          @var string ICCID
         *          @var string planName
         *          @var string serviceType
         *          @var string size
         *          @var string tethering Tethering enabled/disable ("Yes"/"No")
         *          @var string intlCalling International calling allowed ("Yes"/"No")
         *          @var string intlRoaming International roaming allowed ("Yes"/"No")
         *          @var string <feature name> Other supported features (optional)
         *      }
         *      @var string phoneNumber Phone number to activate service on (optional)
         * }
         */

        $order = wc_get_order( $order_id );
        foreach ($order->get_items() as $item) {
            // $product_id = $item->get_product_id();
            // error_log("TEUM: product ID => " . $product_id);
            // $term_list = wp_get_post_terms($product_id, 'product_cat', array('fields'=>'ids'));
            // error_log("TEUM: term_list => " . print_r($term_list, true));
            // $category_id = (int)$term_list[0];
            // error_log("TEUM: category ID => " . $category_id);
            // $category = get_term_link ($category_id, 'product_cat');
            // error_log("TEUM: category => " . print_r($category, true));
            // if (strcasecmp($category, "Plans") == 0) {
            //     $product = wc_get_product($product_id);
            //     error_log("TEUM: product => " . print_r($product, true));
            //     $sku = $product->get_sku();
            //     error_log("TEUM: Found SKU => " . $sku);
            //     break;
            // }
            $product = wc_get_product($item->get_product_id());
            if (teum_isPlan($product) === true) {
               	$sku = $product->get_attribute('pareteum_sku');
                if (empty($sku)) {
                    $sku = "Pareteum SKU Not Defined";
                    error_log("TEUM: Custom attribute SKU not found");
                }
                break;
            }
            $this->mobilityApi->addSubscriber($subscriber_info);
        }
        error_log("TEUM: SKU for ". $order_id . ' => ' . $sku);
		if ($sku_components = $this->_sku_decode($sku)) {
            $imei = sanitize_text_field($_POST['imei']);
            $iccid = sanitize_text_field($_POST['iccid']);
            $service = array(
            "characteristics" => array(
            	"serviceZipCode" => sanitize_text_field($_POST['postcode']),
            		"IMEI" => $imei,
            	  	"ICCID" => $iccid,
            	  	"planName" => $sku_components['plan_name']['api'],
              		"serviceType" => $sku_components['service_type']['api'],
             		"size" => $sku_components['size']['api'],
             		"tethering" => $sku_components['tethering']['api'],
             		"intlCalling" => "No",
            	    "intlRoaming" => "No"
            	)
            );

            // TODO: Should verify all digits as well
            if (strlen($phonenumber) == 10) {
                // Add the number to the service info as well if we have one that looks valid
                $service['phoneNumber'] = $phonenumber;

                // Save the number being activated into the meta data too
                if (update_post_meta($order_id, 'pareteum_phonenumber', $phonenumber) === false) {
                        error_log("TEUM: Error adding the phone number to the order's meta data");
                }
            }

            // Add info to the order meta data too
            if (update_post_meta($order_id, 'pareteum_imei', $imei) === false) {
                error_log("TEUM: Error adding the IMEI to the order's meta data");
            }
            if (update_post_meta($order_id, 'pareteum_iccid', $iccid) === false) {
                error_log("TEUM: Error adding the ICCID to the order's meta data");
            }
            return $service;
		} else {
            error_log("TEUM: decoding the sku failed");
        }
        return false;
    }

    function _activate($subscriber, $service, $order_id) {

        $activation_info = get_post_meta($order_id, '_pareteum_activation_info', true);
        if (is_array($activation_info) && array_key_exists('operation_id', $activation_info)) {
            $result = $this->mobilityApi->addSubscription($subscriber, $service, $activation_info['operation_id']);
        } else {
            $result = $this->mobilityApi->addSubscription($subscriber, $service);
        }

        if ($result['resultType'] == 'Success') {

            error_log("TEUM: Activation request submitted: " . print_r($result, true));

            // (
            //     [resultType] => Success
            //     [resultCode] => 0
            //     [messages] => Array
            //         (
            //             [0] => Operation performed successfully
            //         )
            //     [results] => Array
            //         (
            //             [0] => Array
            //                 (
            //                         [status] => Pending
            //                         [id] => 5fc17d95266d2b438e2cc961
            //                         [number] => 1234567890
            //                         [operation_id] => 12345
            //                 )
            //         )
            // )

            $activation_id = $result['results'][0]['id'];
            $activation_status = strtolower($result['results'][0]['status']);
            $activation_operation_id = $result['results'][0]['operation_id'];

            $activation_info = array(
                'id' => $activation_id,
                'operation_id' => $activation_operation_id,
                'service' => $service,
                'subscriber' => $subscriber,
                'status' => $activation_status
            );

            if (array_key_exists('number', $result['results'][0])) {
                $activation_info['phonenumber'] = $result['results'][0]['number'];
                if (update_post_meta($order_id, 'pareteum_phonenumber', $activation_info['phonenumber']) === false) {
                    error_log("Error adding phone number to meta data for order " . $order_id);
                }
            }

            if (update_post_meta($order_id, '_pareteum_activation_info', $activation_info) === false) {
                    error_log("TEUM: Error adding the activation info to the order's meta data");
            }
            if (update_post_meta($order_id, 'pareteum_activation_id', $activation_id) === false) {
                    error_log("TEUM: Error adding the activation ID to the order's meta data");
            }
            if (update_post_meta($order_id, 'pareteum_operation_id', $activation_operation_id) === false) {
                    error_log("TEUM: Error adding the activation operation ID to the order's meta data");
            }
            if (update_post_meta($order_id, 'pareteum_activation_status', $activation_status) === false) {
                    error_log("TEUM: Error adding the activation status to the order's meta data");
            }
            $this->_show_success("Activation started");
            return true;
        } else {
            error_log("TEUM: Activation request failed: " . print_r($result, true));
            wc_get_template('activation.php',
                            array('orderId' => $order_id,
                                  'resultType' => 'Activation Error',
                                  'errorMessage' => $result['messages'][0]),
                            '',
                            plugin_dir_path( __FILE__ ) . 'templates/' );
            return false;
        }
    }

    function _setup_portin($phonenumber) {
        /*
         * @param array $portinfo {
         *      @var int $subscriberId
         *      @var string $phonenumber
         *      @var string $serviceZipCode
         *      @var strring $portRequestLineId Phone number to port
         *      @var array $authorizer {
         *          @var string $firstName
         *          @var string $lastName
         *          @var array $address {
         *              @var string $streetAddress
         *              @var string $city
         *              @var string $state
         *              @var string $zipCode
         *          }
         *      }
         *      @var array $serviceInfo {
         *          @var string $area
         *      }
         *      @var array $oldServiceProvider {
         *          @var string $accountNumber
         *          @var string $password
         *          @var string firstName
         *          @var string $lastName
         *      }
         * }
        */
        $portininfo = array(
          "phoneNumber" => $phonenumber,
          "serviceZipCode" => sanitize_text_field($_POST['postcode']),
          "portRequestLineId" => $phonenumber,
          "authorizer" => array(
            "firstName" => sanitize_text_field($_POST['auth_first_name']),
            "lastName" => sanitize_text_field($_POST['auth_last_name']),
            "address" => array(
              "streetAddress" => sanitize_text_field($_POST['auth_street_address']),
              "addressLine2" => sanitize_text_field($_POST['auth_address_line2']),
              "city" => sanitize_text_field($_POST['auth_city']),
              "state" => sanitize_text_field($_POST['auth_state']),
              "zipCode" => sanitize_text_field($_POST['auth_postcode'])
            )
          ),
          "serviceInfo" => array( "area" => "0"),
          "oldServiceProvider" => array(
            "accountNumber" => sanitize_text_field($_POST['auth_account']),
            "password" => sanitize_text_field($_POST['auth_password']),
            "firstName" => sanitize_text_field($_POST['auth_first_name']),
            "lastName" => sanitize_text_field($_POST['auth_last_name'])
          )
        );
        return $portininfo;
    }

    function _portin($subscriber, $service, $portininfo, $order_id, $patch=false) {
        # port & activate

        $activation_info = get_post_meta($order_id, 'pareteum_activation_info', true);
        if (array_key_exists('operation_id', $activation_info)) {
            $operation_id = $activation_info['operation_id'];
            if ($patch) {
                $result = $this->mobilityApi->patchPortSubscription($subscriber, $service, $portininfo, $operationId);
            } else {
                $result = $this->mobilityApi->addPortSubscription($subscriber, $service, $portininfo, $operationId);
            }
        } else {
            if ($patch) {
                $result = $this->mobilityApi->patchPortSubscription($subscriber, $service, $portininfo);
            } else {
                $result = $this->mobilityApi->addPortSubscription($subscriber, $service, $portininfo);
            }
        }

        $activation_info = array(
            'id' => $service['phoneNumber'],
            'phonenumber' => $service['phoneNumber'],
            'service' => $service,
            'subscriber' => $subscriber,
            'portin' => $portininfo,
            'status' => 'op'
        );

        if ($result['resultType'] == 'Success') {

            error_log("TEUM: Port & activation request submitted: " . print_r($result, true));

            if (array_key_exists('eligible', $result['results'][0]) &&
                (strcasecmp($result['results'][0]['eligible'], 'false') == 0)) {
                // Number not eligible to port
                $activation_info['status'] = 'er';
                $activation_info['message'] = $result['messages'][0];
                if (update_post_meta($order_id, '_pareteum_activation_info', $activation_info) === false) {
                    error_log("TEUM: Error adding the activation info (port) to the order's meta data (".$order_id.")");
                }
                if (update_post_meta($order_id, 'pareteum_port_status', 'er') === false) {
                    error_log("TEUM: Error adding the port status to the order's meta data (".$order_id.")");
                }
                if (update_post_meta($order_id, 'pareteum_phonenumber', $service['phoneNumber']) === false) {
                    error_log("Error adding phone number to meta data for order " . $order_id);
                }

                wc_get_template('portin.php',
                                array('order_id' => $order_id,
                                      'resultType' => 'Eligibility Failed',
                                      'errorMessage' => $result['messages'][0] . " (" . $service['phoneNumber'] .")"),
                                '',
                                plugin_dir_path( __FILE__ ) . 'templates/' );
                return false;
            } else {
                // (
                //     [resultType] => Success
                //     [resultCode] => 0
                //     [messages] => Array
                //         (
                //             [0] => Operation performed successfully
                //         )
                //     [results] => Array
                //         (
                //             [0] => Array
                //                 (
                //                         [status] => Pending
                //                         [operation_id] => 12345
                //                 )
                //         )
                // )

                $portin_operation_id = $result['results'][0]['operation_id'];

                $portstatus = $this->mobilityApi->getPortinStatus($service['phoneNumber']);

                /*
                 * @return array {
                 *    @var int resultCode
                 *    @var string resultType
                 *    @var string statusReasonCode
                 *    @var string statusReasonDescription
                 *    @var array messages []
                 * }
                */

                if ($portstatus['resultType'] == 'Success') {
                    $status = strtolower($portstatus['statusReasonCode']);
                } else {
                    $status = 'er';
                }
                $activation_info['status'] = $status;
                $activation_info['operation_id'] = $portin_operation_id;

                if (update_post_meta($order_id, '_pareteum_activation_info', $activation_info) === false) {
                    error_log("TEUM: Error adding the activation info (port) to the order's meta data");
                }
                if (update_post_meta($order_id, 'pareteum_port_status', $status) === false) {
                    error_log("TEUM: Error adding the port status to the order's meta data");
                }
                if (update_post_meta($order_id, 'pareteum_operation_id', $portin_operation_id) === false) {
                        error_log("TEUM: Error adding the activation operation ID to the order's meta data");
                }
                if (update_post_meta($order_id, 'pareteum_phonenumber', $service['phoneNumber']) === false) {
                    error_log("Error adding phone number to meta data for order " . $order_id);
                }

                $this->_show_success("Number transfer started");
                return true;
            }
        } else {
            error_log("TEUM: Port/activate request failed: " . print_r($result, true));
            $activation_info['status'] = 'er';
            if (update_post_meta($order_id, '_pareteum_activation_info', $activation_info) === false) {
                error_log("TEUM: Error adding the activation info (port) to the order's meta data (".$order_id.")");
            }
            if (update_post_meta($order_id, 'pareteum_port_status', 'er') === false) {
                error_log("TEUM: Error adding the port status to the order's meta data (".$order_id.")");
            }
            wc_get_template('portin.php',
                            array('order_id' => $order_id,
                                  'resultType' => $result['resultType'],
                                  'errorMessage' => $result['messages'][0]),
                            '',
                            plugin_dir_path( __FILE__ ) . 'templates/' );
            return false;
        }
    }

    function _delete_meta($order_id) {
        delete_post_meta($order_id, '_pareteum_activation_info');
        delete_post_meta($order_id, 'pareteum_imei');
        delete_post_meta($order_id, 'pareteum_iccid');
        delete_post_meta($order_id, 'pareteum_phonenumber');
        delete_post_meta($order_id, 'pareteum_port_status');
        delete_post_meta($order_id, 'pareteum_activation_status');
        delete_post_meta($order_id, 'pareteum_activation_id');
        delete_post_meta($order_id, 'pareteum_operation_id');
    }

    function activations_endpoint_content($page = "activation") {
        global $wpdb;

        $currentUser = wp_get_current_user();
        error_log("TEUM: activations_endpoint_content; current User => " . print_r($currentUser, true));

        if(isset($_POST['submit'])) {

            // Add the activation ID to the order meta data
            $order_id = sanitize_text_field($_POST['order_id']);

            // Verify this is for the current user
            if (get_post_meta($order_id, '_customer_user', true) != $currentUser->ID) {
                error_log("TEUM: Attempt to " . sanitize_text_field($_POST['submit']) . " for order " . $order_id . " from incorrect user " . $currentUser->ID);
                $this->_show_error("Problem with your order information; please contact us.");
                return;
            }

            $subscriberId = get_user_meta($currentUser->ID, "pareteum_subscriber_id", true);
            error_log("TEUM: Subscriber ID: " . print_r($subscriberId, true));

            if ($subscriberId === false) {
                // Invalid WP user?
                // What do we do here?
                error_log("TEUM: subscriber ID => False");
                $this->_show_error("Failed to find account information; please contact us.");
                return;
            } else {
                if (strlen($subscriberId) == 0) {
                    // Need to create a subscriber
                    $subscriberId = $this->_create_subscriber($currentUser);
                    if ($subscriberId === false) {
                        $this->_show_error("Failed to create account; please contact us.");
                        return;
                    }
                }
            }

            // Assume by here we have a subscriber ID
            $subscriber = $this->_setup_subscriber($subscriberId);

            $phonenumber = sanitize_text_field($_POST['phone_number']);
            $service = $this->_setup_service($order_id, $phonenumber);

            if ($service === false) {
                // TODO: Need to show error to user and return to form here
                error_log("TEUM: Failed to set up service; aborting activation");
                $this->_show_error("Failed to set up service information; please contact us.");
            }

            error_log("TEUM: Subscriber data => " . print_r($subscriber, true));
            error_log("TEUM: Service data => " . print_r($service, true));

            if ($_POST['submit'] == 'activation') {
                // activate a new number
                $this->_activate($subscriber, $service, $order_id);
                return;
            } elseif ($_POST['submit'] == 'portin') {
                # initiate a port request

                $portininfo = $this->_setup_portin($phonenumber);

                error_log("TEUM: Port data => " . print_r($portininfo, true));

                // Submit the API request
                $activation_info = get_post_meta($order_id, '_pareteum_activation_info', true);
                if (is_array($activation_info) && array_key_exists('status', $activation_info)) {
                    switch (strtolower($activation_info['status'])) {
                        case "ct":
                            error_log("Port status is Conflict => patching");
                            $this->_portin($subscriber, $service, $portininfo, $order_id, true);
                            return;
                        case "er":
                        case "cn":
                            error_log("Port status is Error/Canceled => posting");
                            $this->_portin($subscriber, $service, $portininfo, $order_id);
                            return;
                        case "cf":
                            error_log("Port status is confirmed => just activate");
                            $this->_activate($subscriber, $service, $order_id);
                            return;
                        default:
                            error_log("Attempt to resubmit port in invalid state");
                            $this->_show_error("Internal error (port in invalid state); please contact us.");
                            return;
                    }
                } else {
                    $this->_portin($subscriber, $service, $portininfo, $order_id);
                    return;
                }
            } else {
                // Unknown request
                $this->_show_error("Page not found.");
                return;
            }
        } else {
            // Show pages
            $order_id = sanitize_text_field($_REQUEST['order_id']);
            if (strlen($order_id) == 0) {
                error_log("TEUM: No order ID provided for " . $page);
                $this->_show_error("Internal error (no order ID)");
                return;
            }

            error_log("TEUM: GET order_id = ". $order_id);

            // Verify this is for the current user
            if (get_post_meta($order_id, '_customer_user', true) == $currentUser->ID) {
                error_log("TEUM: correct customer; page = " . $page);
                if ($page == "activation") {
                    wc_get_template( 'activation.php', array(), '', plugin_dir_path( __FILE__ ) . 'templates/' );
            	} else if ($page == "portin") {
                    wc_get_template( 'portin.php', array(), '', plugin_dir_path( __FILE__ ) . 'templates/' );
            	} else if ($page == "cancelport") {
                    // No need to render anything for this one; just submit the cancel and return to the pareteum_dashboard_content
                    $activation_info = get_post_meta($order_id, '_pareteum_activation_info', true);
                    $status = strtolower($activation_info['status']);
                    if (in_array($status, array("op","ct","cf"))) {
                        // Cancel the port
                        $result = $this->mobilityApi->cancelPortin($activation_info['portin']['phoneNumber'], $activation_info['portin']['serviceZipCode']);

                        if ($result['resultType'] == "Success") {
                            $this->_delete_meta($order_id);
                            $this->_show_success("Operation canceled");
                            return;
                        } else {
                            error_log("TEUM: Failed to cancel port");
                            $this->_show_error("Failed to cancel number transfer; please contact us.");
                            return;
                        }
                    } else {
                      // Just delete all the meta data
                      $this->_delete_meta($order_id);
                      $this->_show_success("Operation canceled");
                      return;
                    }
                } else if ($page == "cancelactivation") {
                    $activation_info = get_post_meta($order_id, '_pareteum_activation_info', true);
                    $status = strtolower($activation_info['status']);
                    error_log("TEUM: Cancel Activation for " . $order_id . "(status = " . $status .")");

                    // Only allow for rejected state
                    if ($status == "rejected") {
                        // Cancel the activation (just need to delete our meta data)
                        $this->_delete_meta($order_id);
                        error_log("TEUM: meta data deleted");
                    }
                    $this->_show_success("Activation canceled");
                } else {
                    error_log("TEUM: unknown page requested: " . $page);
                    $this->_show_error("Page not found");
                    return;
                }
            } else {
                error_log("Attempt to modify order " . $order_id . " from incorrect user " . $currentUser->ID);
                $this->_show_error("Problem with your order information; please contact us.");
                return;
            }
        }
    }

	function ajax_handler() {

		if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			$method = $_REQUEST['method'];

			if ($method == "device_info") {
				$imei = $_REQUEST["imei"];
				$result = $this->mobilityApi->getDeviceInfo($imei);
			} else {
				// TODO: Better error response
				$result = array(
					"resultType" => "Error",
    				"resultCode" => 1,
    				"messages" => array(
    					"Unknown AJAX method"
    				)
    			);
			}
			// Send the result
	     	echo json_encode($result);
	   } else {
	      header("Location: ".$_SERVER["HTTP_REFERER"]);
	   }

	   die();

	}

	function no_priv() {
		// TODO: Add a better error response here
		$result = array(
			"resultType" => "Error",
			"resultCode" => 1,
			"messages" => array(
				"Not logged in"
			)
		);
		echo json_encode($result);
		die();
	}

	function _sku_decode($sku) {

		// Contructs a PHP associative array from a SKU, e.g.
		//
		// A product is an array of arrays:
		//
		// [
		//    "plan_name" :
		//       [
		//           "label" => "Mobile Select",
		//           "api => "Mobile Select"
		//       ],
		//    "service_type" :
		//       [
		//           "label" => "Voice & Data",
		//           "api => "V"
		//       ],
		//    "size" :
		//       [
		//           "label" => "1GB",
		//           "api => "1GB"
		//       ],
		//    "tethering" :
		//       [
		//           "label" => "Tethering Allowed",
		//           "api => "Yes"
		//       ]
		// ]
		//

		$valid_sku = true; // Assume it's good until it isn't

		$sku_array = explode(":",$sku);

		//print_r ($sku_array);

		// PLAN NAME
		$plan_name['label'] = $sku_array[0];
		$plan_name['api'] = strtolower($sku_array[0]);
		$product['plan_name'] = $plan_name;

		// SERVICE TYPE
		switch ($sku_array[1]) {
			case "V":
    			$service_type['label'] = "Data and Voice";
    			$service_type['api'] = "Data and Voice";
    			break;
			case "D":
    			$service_type['label'] = "Data Only";
    			$service_type['api'] = "Data Only";
    			break;
			default:
    			$service_type['label'] = "PRODUCT ERROR: Service Type";
    			$service_type['api'] = "";
    			$valid_sku = false;
    			break;
		}

		$product['service_type'] = $service_type;

		// PLAN SIZE
		$plan_size['label'] = $sku_array[2];
		$plan_size['api'] =  strtolower($sku_array[2]);

		$product['size'] = $plan_size;

		// TETHERING
		switch ($sku_array[3]) {
			case "Y":
    			$tethering['label'] = "Tethering Allowed";
    			$tethering['api'] = "Yes";
    			break;
			case "N":
    			$tethering['label'] = "Tethering Not Allowed";
    			$tethering['api'] = "No";
    			break;
			default:
    			$tethering['label'] = "PRODUCT ERROR: Tethering";
    			$tethering['api'] = "";
    			$valid_sku = false;
    			break;
		}

		$product['tethering'] = $tethering;

		//print_r ($product);

		//echo ("Plan Name : " . $product['plan_name']['label'] . "</br>");
		//echo ("Service Type : " . $product['service_type']['label'] . "</br>");
		//echo ("Size : " . $product['size']['label'] . "</br>");
		//echo ("Tethering : " . $product['tethering']['label'] . "</br>");

		if ($valid_sku) {
			return $product;
		} else {
			error_log("TEUM: Attempted to decode an invalid SKU => " . print_r($sku, true));
			return false; // Invalid SKU - check the config
		}
	}
}
?>
