<div>
    <h3>We Encountered a Problem</h3>
    <p><?=$Message?></p>
</div>
