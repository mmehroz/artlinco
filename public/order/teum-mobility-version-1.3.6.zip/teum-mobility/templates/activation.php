<?php

    // TEUM Utilities
    // Needs to be included like this from templates as includes dir is not in include_path
    require_once (plugin_dir_path( __DIR__ ) . 'includes/teum-utilities.php');

    $states = array(
        "AL" => "Alabama",
        "AK" => "Alaska",
        "AZ" => "Arizona",
        "AR" => "Arkansas",
		"AS" => "American Samoa",
        "CA" => "California",
        "CO" => "Colorado",
        "CT" => "Connecticut",
        "DE" => "Delaware",
        "DC" => "District Of Columbia",
        "FL" => "Florida",
        "GA" => "Georgia",
		"GU" => "Guam",
        "HI" => "Hawaii",
        "ID" => "Idaho",
        "IL" => "Illinois",
        "IN" => "Indiana",
        "IA" => "Iowa",
        "KS" => "Kansas",
        "KY" => "Kentucky",
        "LA" => "Louisiana",
        "ME" => "Maine",
        "MD" => "Maryland",
        "MA" => "Massachusetts",
        "MI" => "Michigan",
        "MN" => "Minnesota",
        "MS" => "Mississippi",
        "MO" => "Missouri",
		"MP" => "Northern Mariana Islands",
        "MT" => "Montana",
        "NE" => "Nebraska",
        "NV" => "Nevada",
        "NH" => "New Hampshire",
        "NJ" => "New Jersey",
        "NM" => "New Mexico",
        "NY" => "New York",
        "NC" => "North Carolina",
        "ND" => "North Dakota",
        "OH" => "Ohio",
        "OK" => "Oklahoma",
        "OR" => "Oregon",
        "PA" => "Pennsylvania",
		"PR" => "Puerto Rica",
        "RI" => "Rhode Island",
        "SC" => "South Carolina",
        "SD" => "South Dakota",
        "TN" => "Tennessee",
        "TX" => "Texas",
        "UT" => "Utah",
		"VI" => "US Virgin Islands",
        "VT" => "Vermont",
        "VA" => "Virginia",
        "WA" => "Washington",
        "WV" => "West Virginia",
        "WI" => "Wisconsin",
        "WY" => "Wyoming",
        "AA" => "Armed Forces (AA)",
        "AE" => "Armed Forces (AE)",
        "AP" => "Armed Forces (AP)"
    );

    // The order ID can come in via template arguments in case of
    // an error, or be in the GET parameters when linked from another page
    if (!isset($order_id)) {
        $order_id = sanitize_text_field($_REQUEST['order_id']);
    }
    $order = wc_get_order($order_id);
    // Check the order belongs to this customer
    if ($order->get_user_id() != get_current_user_id()) {
        // TODO: Work out what to do here to redirect away from the activation since this order is not
        // for this customer
        die();
    }

    foreach ($order->get_items() as $item) {
        $product = wc_get_product($item->get_product_id());
		if (teum_isPlan($product) === true) {
            $planName = $product->get_name();
            break;
        }
    }

    if (!isset($planName)) {
        error_log("TEUM: No plan item found to activate");
        $planName = "Unknown";
    }

    $activation_info = get_post_meta($order_id, '_pareteum_activation_info', true);

    if ($activation_info) {
      // Retrying the activation
      $firstName = $activation_info['subscriber']['firstName'];
      $lastName = $activation_info['subscriber']['lastName'];
      $streetAddress = $activation_info['subscriber']['address']['streetAddress'];
      $addressLine2 = $activation_info['subscriber']['address']['addressLine2'];
      $city = $activation_info['subscriber']['address']['city'];
      $state = $activation_info['subscriber']['address']['state'];
      $zipCode = $activation_info['subscriber']['address']['zipCode'];
      $email = $activation_info['subscriber']['email'];
      $contactNumber = $activation_info['subscriber']['contactNumber'];
      $imei = $activation_info['service']['characteristics']['IMEI'];
      $iccid = $activation_info['service']['characteristics']['ICCID'];
      if (array_key_exists('phonenumber', $activation_info)) {
          $phoneNumber = $activation_info['phonenumber'];
      } else {
          $phoneNumber = '';
      }
    } else {
      $firstName = $order->get_billing_first_name();
      $lastName = $order->get_billing_last_name();
      $streetAddress = $order->get_billing_address_1();
      $addressLine2 = $order->get_billing_address_2();
      $city = $order->get_billing_city();
      $state = $order->get_billing_state();
      $zipCode = $order->get_billing_postcode();
      $email = $order->get_billing_email();
      $contactNumber = $order->get_billing_phone();
      $imei = '';
      $iccid = '';
      $phoneNumber = '';
    }

    if (isset($resultType)) {
        ?>
            <div class="woocommerce-error">
                <h2><?=sanitize_text_field($resultType)?></h2>
                <?=sanitize_text_field($errorMessage)?>
            </div>
        <?php
    }
?>

<style>
.teum-processing {
    background-image:url(<?=WP_PLUGIN_URL."/teum-mobility/images/three-dots.svg"?>) !important;
    background-position: center 30% !important;
    background-repeat: no-repeat !important;
}
#teumoverlay {
    position: fixed;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.85);
    top: 0;
    left: 0;
    z-index: 9999;
}
#teummessage {
    position: absolute;
    top: 35%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 2.5em;
    font-weight: bold;
    color: white;
}
</style>
<div id="teumoverlay" style="display:none;">
    <div id="teummessage">Processing - Please Wait</div>
</div>
<script>
    function teum_showOverlay() {
        jQuery('#teumoverlay').show();
        return true;
    }
</script>
<div class="woocommerce-address-fields">
    <div class="activation">
        <form action="" method="post" onsubmit="teum_showOverlay();">
            <div class="woocommerce-address-fields__field-wrapper">
                <input type="hidden" name="plan_activation" class="plan_activation" />
                <input type="hidden" name="post_id_activation" class="post_id_activation"/>
                <input type="hidden" name="order_id" value="<?=$order_id?>" />
                <div id="subscriber_info">
                    <fieldset>
                        <legend>Subscriber</legend>
                        <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                            <label for="billing_first_name" class="">First name <abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="first_name" id="first_name" value="<?=$firstName?>" placeholder="" autocomplete="given-name" />
                            </span>
                        </p>
                        <p class="form-row form-row-last validate-required" id="last_name_field" data-priority="20">
                            <label for="last_name" class="">Last name&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="last_name" id="last_name" value="<?=$lastName?>" autocomplete="family-name" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide address-field validate-required" id="street_address_field" data-priority="30">
                            <label for="street_address" class="">Street Address&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="street_address" id="street_address" value="<?=$streetAddress?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide address-field" id="street_address_field" data-priority="40">
                            <label for="street_address2" class="">Address Line 2&nbsp;</label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="address_line2" id="address_line2" value="<?=$addressLine2?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide address-field validate-required" id="city_field" data-priority="50" data-o_class="form-row form-row-wide address-field validate-required">
                            <label for="city" class="">City&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="city" id="city" placeholder="" autocomplete="address-level2" value="<?=$city?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide address-field validate-required validate-state" id="state_field" data-priority="60" data-o_class="form-row form-row-wide address-field validate-required validate-state">
                            <label for="state" class="">State&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <select name="state" id="state" class="woocommerce-Input woocommerce-Input--text input-text" data-placeholder="Select an option…" data-input-classes="" data-o_class="form-row form-row-wide address-field validate-required validate-state" >
                                    <option value="">Select an option…</option>
                                        <?php
                                            foreach($states as $abbv => $state_name) {
                                                if ($abbv == $state) {
                                                    $selected = "selected";
                                                } else {
                                                    $selected = "";
                                                }
                                                echo "<option value='$abbv' $selected>$state_name</option>";
                                            }
                                        ?>
                                </select>
                            </span>
                        </p>
                        <p class="form-row form-row-wide address-field validate-required validate-postcode" id="postcode_field" data-priority="70" data-o_class="form-row form-row-wide address-field validate-required validate-postcode">
                            <label for="postcode" class="">ZIP&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="postcode" id="postcode" placeholder=""  autocomplete="postal-code" value="<?=$zipCode?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide validate-required" id="email_field" data-priority="80" o_class="form-row form-row-wide validate-required">
                            <label for="email" class="">Email&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="email" placeholder="" autocomplete="email" value="<?=$email?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide">
                            <label for="phone">Contact Number</label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" id="contact_phone" name="contact_phone" value="<?=$contactNumber;?>" />
                            </span>
                        </p>

                    </fieldset>
                </div>

                <div id="phone_plan_info">
                    <fieldset>
                        <legend>Phone and Plan Information</legend>
                        <input type="hidden" id="phone_number" name="phone_number" value="<?=$phoneNumber?>" />
                        <p class="form-row form-row-wide validate-required" id="imei" data-priority="101" data-o_class="form-row form-row-wide address-field validate-required">
                            <label for="imei" class="">IMEI&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="imei" id="imei" value="<?=$imei?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide validate-required" id="imei" data-priority="102" data-o_class="form-row form-row-wide address-field validate-required">
                            <label for="iccid" class="">ICCID&nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="iccid" id="iccid" value="<?=$iccid?>" />
                            </span>
                        </p>

                        <p class="form-row form-row-wide">
                            <label for="data_prt">Plan Name</label>
                            <span class="woocommerce-input-wrapper">
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="plan_name" id="plan_name" value="<?=$planName?>" disabled/>
                            </span>
                        </p>
                    </fieldset>
                </div>
            </div>
            <?php wp_nonce_field( '_wcsnonce', '_wcsnonce' ); ?>
            <button type="submit" class="woocommerce-Button button" name="submit" value="activation">Activate</button>
        </form>
    </div>
</div>
