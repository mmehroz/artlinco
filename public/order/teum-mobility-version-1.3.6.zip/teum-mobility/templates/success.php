<div>
    <h3>Completed Successfully</h3>
    <p><?=$Message?></p>
</div>
<script>
setTimeout("window.location='/my-account/'",5000);
</script>
