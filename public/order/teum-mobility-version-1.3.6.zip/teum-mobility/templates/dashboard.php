<style>
.teum-button {
	padding: 10px;
	width: 30%;
}
.teum-button a {
	color: white;
}
.teum-button .col-1 {
	margin-left: 10%;
}
.teum-button .col-2 {
	margin-right: 10%;
}
.teum-small-button {
	padding: 5px;
	margin: 2px;
}
.teum-small-button a {
	color: white;
}
</style>

<?php
	// Get all customer orders
  $customer_orders = get_posts([
      'numberposts' => -1,
      'meta_key' => '_customer_user',
      'orderby' => 'date',
      'order' => 'DESC',
      'meta_value' => get_current_user_id(),
      'post_type' => ['shop_subscription'],
      'post_status' => array_merge(array_keys(wc_get_order_statuses()), ['wc-active']),
	  ]);

  $activations_active = [];
  $activations_in_process = [];
  $activations_activated = [];

  // Set up the API in case we need it
  $mobility = new Mobility();

  if (count($customer_orders) > 0) {
  	$order_pending = false;
  	foreach($customer_orders as $order) {
  		$activation_info = get_post_meta($order->ID, '_pareteum_activation_info', true);
		if (is_array($activation_info)) {
			error_log("Found activation info: " . print_r($activation_info, true));
  			if (strlen($activation_info['id']) == 0) {
  				if (!$order_pending) {
					error_log("Choosing order ". $order->ID . " as order to activate [1]");
  					$order_id = $order->ID;
    				$order_pending = true;
  				}
  			} elseif (!(strcasecmp ($activation_info['status'], 'Active') === 0)) { // Confirm porting numbers move to this state when done
				error_log("Adding order ". $order->ID ." to activations in process list");
  				$activation_info['order_id'] = $order->ID;
  				$activations_active[] = $activation_info;
  			} else {
				error_log("Adding order ". $order->ID ." to activated list");
  				$activation_info['order_id'] = $order->ID;
  				$activations_activated[] = $activation_info;
  			}
		} else {
			if (!$order_pending) {
				error_log("Choosing order ". $order->ID . " as order to activate [2]");
				$order_id = $order->ID;
				$order_pending = true;
			}
		}
  	}

    foreach($activations_active as $activation_info) {
			/*
		     * @return array (
		     *      @var int resultCode
		     *      @var string resultType
		     *      @var array messages
		     *      @var array results (
		     *          @var string status
		     *          @var string id
		     *          @var string number
		     *      )
			 */
			error_log("Activation Info: " . print_r($activation_info, true));

			if (strlen($activation_info['id']) == 10) { // id is actually the MSISDN during Porting phase
				// Porting phase
				$status = strtolower($activation_info['status']);
				if (in_array($status, ['er'])) {
					// port in error state
					$activation_info['phonenumber'] = $activation_info['id'];
					if (!array_key_exists("message", $activation_info)) {
						$activation_info['message'] = '';
					}
					$activations_in_process[] = $activation_info;
				} else {
					$result = $mobility->getPortinStatus($activation_info['id']);
					if ($result['resultType'] == "Success") {
						$activation_info['status'] = strtolower($result['statusReasonCode']);
						$activation_info['message'] = $result['statusReasonDescription'];
						$activation_info['phonenumber'] = $activation_info['id'];
						$activations_in_process[] = $activation_info;
						if (update_post_meta($activation_info['order_id'], '_pareteum_activation_info', $activation_info) === false) {
			         		error_log("Error updating the activation info (port) for order " . $activation_info['order_id']);
		        		}
						if (update_post_meta($activation_info['order_id'], 'pareteum_port_status', $activation_info['status']) === false) {
			         		error_log("Error updating the port status meta data for order " . $activation_info['order_id']);
		        		}
					} else {
						error_log("Failed to get port status for " . print_r($activation_info, true));
					}
				}
			} else {
				// Activation phase
				$result = $mobility->getActivation($activation_info['id']);
				/***
					{
    					"resultType": "Success",
    					"resultCode": 0,
    					"messages": [
        					"Operation performed successfully."
					    ],
					    "results": [
					        {
					            "status": "Active",
					            "id": "615e4a8e7b415d30848724be",
					            "number": "6362356304"
					        }
					    ]
					}
				**/

				if ($result['resultType'] == "Success") {
					$status = strtolower($result['results'][0]['status']);
					$activation_info['status'] = $status;
					if (array_key_exists('number', $result['results'][0])) {
						$activation_info['phonenumber'] = $result['results'][0]['number'];
						if (update_post_meta($activation_info['order_id'], 'pareteum_phonenumber', $activation_info['phonenumber']) === false) {
							error_log("Error adding phone number to meta data for order " . $activation_info['order_id']);
						}
					}
					if (in_array($status, ['pending', 'reserved', 'rejected'])) {
						error_log("Status = " . $status);
						$activation_info['message'] = $result['messages'][0];
						$activations_in_process[] = $activation_info;
					} else {
						// active
						error_log("Adding order ". $activation_info['order_id'] ." to activated list [2]");
  						$activations_activated[] = $activation_info;
					}
					if (update_post_meta($activation_info['order_id'], 'pareteum_activation_status', $status) === false) {
						error_log("Error updating activation status in meta data for order " . $activation_info['order_id']);
					}
					if (update_post_meta($activation_info['order_id'], '_pareteum_activation_info', $activation_info) === false) {
		         		error_log("Error updating the activation info for order " . $activation_info['order_id']);
	        		}
				} else {
					error_log("Failed to get activation status for " . print_r($activation_info, true));
				}
			}
		} /* foreach */

  	if ($order_pending) {
    	?>
	    	<p>You have a pending activation; choose whether to activate a new number or bring your existing one over.</p>
				<div id='action_buttons' class="col2-set">
					<div class="woocommerce-Button button teum-button col-1">
						<a href="/my-account/activations/activation?order_id=<?=$order_id?>">Activate New Number</a>
					</div>
					<div class="woocommerce-Button button teum-button col-2">
						<a href="/my-account/activations/portin?order_id=<?=$order_id?>">Bring my Number</a>
					</div>
				</div>
			<?php
		}
	}

	// Translate the status to something more human readable
	$statusMeanings = [
			"cf" => "Confirmed",
			"cn" => "Canceled",
			"co" => "Completed",
			"ct" => "Conflict",
			"dn" => "Denied",
			"er" => "Error",
			"op" => "Open"
		];

?>
<?php
	if (count($activations_in_process) > 0) {
		?>
			<div id="current_activations" class="">
				<h2>Activations in Process</h2>
				<table class="my_account_subscriptions woocommerce-orders-table woocommerce-MyAccount-subscriptions shop_table shop_table_responsive woocommerce-orders-table--subscriptions">
					<thead>
						<tr>
							<th class="subscription-id order-number woocommerce-orders-table__header woocommerce-orders-table__header-order-number woocommerce-orders-table__header-subscription-id"><span class="nobr"><?php esc_html_e( 'Phone Number', 'pareteum' ); ?></span></th>
							<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Status', 'pareteum' ); ?></span></th>
							<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'SIM', 'pareteum' ); ?></span></th>
							<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Message', 'pareteum' ); ?></span></th>
							<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Action', 'pareteum' ); ?></span></th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($activations_in_process as $activation_info) {
								if ($activation_info['status'] != 'active') {
									?>
										<tr class="order">
											<td class="" data-title="<?php esc_attr_e( 'Phone Number', 'pareteum' ); ?>">
												<?php if (array_key_exists('phonenumber', $activation_info)) { echo esc_attr($activation_info['phonenumber']); } ?>
											</td>
											<td class="" data-title="<?php esc_attr_e( 'Status', 'pareteum' ); ?>">
												<?php
														if (array_key_exists($activation_info['status'], $statusMeanings)) {
															echo esc_attr($statusMeanings[$activation_info['status']]);
														} else {
															echo esc_attr(ucfirst($activation_info['status']));
														}
												?>
											</td>
											<td class="" data-title="<?php esc_attr_e( 'SIM', 'pareteum' ); ?>">
												<?php echo esc_attr($activation_info['service']['characteristics']['ICCID']); ?>
											</td>
											<td class="" data-title="<?php esc_attr_e( 'Message', 'pareteum' ); ?>">
												<?php echo esc_attr($activation_info['message']); ?>
											</td>
											<td class="" data-title="<?php esc_attr_e( 'Action', 'pareteum' ); ?>">
												<?php
													if ($activation_info['status'] == 'rejected') {
														?>
															<div class="woocommerce-Button button teum-small-button">
																<a href="/my-account/activations/activation?order_id=<?=$activation_info['order_id']?>">Retry</a>
															</div>
														<?php
													} else if (in_array($activation_info['status'], ["ct", "er", "dn"])) {
														?>
															<div class="woocommerce-Button button teum-small-button">
																<a href="/my-account/activations/portin?order_id=<?=$activation_info['order_id']?>">Retry</a>
															</div>
														<?php
													}
													// Show option to cancel port or activation (if it failed)
													if (in_array($activation_info['status'], ["cf", "ct", "op", "er"])) {
														?>
															<div class="woocommerce-Button button teum-small-button">
																<a href="/my-account/activations/cancelport?order_id=<?=$activation_info['order_id']?>">Cancel</a>
															</div>
														<?php
													} else if (strtolower($activation_info['status']) == 'rejected') {
														?>
															<div class="woocommerce-Button button teum-small-button">
																<a href="/my-account/activations/cancelactivation?order_id=<?=$activation_info['order_id']?>">Cancel</a>
															</div>
														<?php
													}
												?>
											</td>
										</tr>
									<?php
								}
							} /* foreach */
						?>
					</tbody>
				</table>
			</div>
		<?php
	}
?>

<div id="current_plans" class="">
	<h2>Active Plans</h2>
	<?php
		if (count($activations_activated) > 0) {
			?><table class="my_account_subscriptions woocommerce-orders-table woocommerce-MyAccount-subscriptions shop_table shop_table_responsive woocommerce-orders-table--subscriptions">
				<thead>
					<tr>
						<th class="subscription-id order-number woocommerce-orders-table__header woocommerce-orders-table__header-order-number woocommerce-orders-table__header-subscription-id"><span class="nobr"><?php esc_html_e( 'Phone Number', 'pareteum' ); ?></span></th>
						<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Name', 'pareteum' ); ?></span></th>
						<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Status', 'pareteum' ); ?></span></th>
						<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'Plan Size', 'pareteum' ); ?></span></th>
						<th class="subscription-status order-status woocommerce-orders-table__header woocommerce-orders-table__header-order-status woocommerce-orders-table__header-subscription-status"><span class="nobr"><?php esc_html_e( 'SIM', 'pareteum' ); ?></span></th>
					</tr>
				</thead>
				<tbody>
					<?php
						foreach ($activations_activated as $sub ) {
							?>
								<tr class="order">
									<td class="" data-title="<?php esc_attr_e( 'Phone Number', 'pareteum' ); ?>">
										<?php echo esc_attr($sub['phonenumber']); ?>
									</td>
									<td class="" data-title="<?php esc_attr_e( 'Name', 'pareteum' ); ?>">
										<?php echo esc_attr($sub['subscriber']['firstName']) . " " . esc_attr($sub['subscriber']['lastName']); ?>
									</td>
									<td class="" data-title="<?php esc_attr_e( 'Status', 'pareteum' ); ?>">
										<?php echo esc_attr($sub['status']); ?>
									</td>
									<td class="" data-title="<?php esc_attr_e( 'Plan Size', 'pareteum' ); ?>">
										<?php echo esc_attr($sub['service']['characteristics']['size']); ?>
									</td>
									<td class="" data-title="<?php esc_attr_e( 'SIM', 'pareteum' ); ?>">
										<?php echo esc_attr($sub['service']['characteristics']['ICCID']); ?>
									</td>
								</tr>
							<?php
						} /* foreach */
					?>
				</tbody>
			</table><?php
		} else {
			echo '<div id="no_active_plans">No active plans</div>';
		}
	?>
</div>
