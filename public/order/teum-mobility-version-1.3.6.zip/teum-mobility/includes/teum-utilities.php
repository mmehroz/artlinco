<?php

/**
 * TEUM Utilities
 */

function teum_isPlanFilterCheck($category) {
	return ($category->name === 'Plans');
}

function teum_isPlan($product) {
	$args = array(
		  'taxonomy' => "product_cat"
		);
	$product_categories = get_terms($args);
	//print_r($product_categories);
	//foreach( $product_categories as $cat ) { echo $cat->name; }
	$plan_categories = array_filter($product_categories, 'teum_isPlanFilterCheck');
	$plan_categories = array_values($plan_categories); // reindex array
	if (count($plan_categories) == 1) {
		//print_r($plan_categories);
		$plan_id = $plan_categories[0]->term_id;
	} else {
		error_log("Wrong number of 'Plans' category: " . count($plan_categories));
		return false;
	}
	// print_r($product_categories);
	if (in_array($plan_id, $product->get_category_ids())) {
		return true;
	} else {
		return false;
	}
}

?>