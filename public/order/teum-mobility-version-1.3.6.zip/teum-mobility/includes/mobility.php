<?php

/**
 * AT&T Mobility API
 */
class Mobility {

    private $mvno = NULL;
    private $username = NULL;
    private $password = NULL;
    private $base_url = NULL;
    /**
     * Constructor
     *
     * @param string $mvno The MVNO ID needed for the API authentication
     * @param string $username The API username
     * @param string $password The API password
     */
    public function __construct() {

        $options = get_option('pareteum_mobility_options');
        if (strcasecmp($options['api_selector'],  'production') == 0) {
            // Use the production account
            $this->mvno = $options['mvno_id'];
            $this->username = $options['api_username'];
            $this->password = $options['api_password'];
            $this->base_url = 'https://prod.mobility-api.pareteum.cloud/v3/mobility/';
        } else {
            // Use the sandbox otherwise
            $this->mvno = $options['sandbox_mvno_id'];
            $this->username = $options['sandbox_username'];
            $this->password = $options['sandbox_password'];
            $this->base_url = 'https://qa.mobility-api.pareteum.cloud/v3/mobility/';
        }
    }

    private function getChannel() {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Expect:"));
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $this->username . ":" . $this->password);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        return $ch;
    }

    /**
     * Get details about a subscriber
     *
     * @param string $identifier An identifier for the subscriber
     * @param string $id_type The type of identifier supplied in $identifier (phonenumber, accountnumber)
     * @return array Subscriber details
     */
    public function getSubscriber($identifier, $id_type="accountnumber") {
        // APIGW-926: $url = $this->base_url . 'accounts/' . $identifier . '?type=' . $id_type . '&MVNO=' . $this->mvno;
        $url = $this->base_url . 'accounts/' . $identifier . '?MVNO=' . $this->mvno;
        if (strcasecmp($id_type, "phonenumber") != 0) {
            $url .= "&type=" . $id_type;
        }
        $ch = $this->getChannel();
        curl_setopt($ch, CURLOPT_URL, $url);
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($result, true);
        /*
         * TODO: Need to check for errors here
         */
        if (!empty($result)) {
            for ($i=0; $i < count($result['subscribers']); $i++) {
                if (isset($result['subscribers'][$i]['address'])) {
                    if (!isset($result['subscribers'][$i]['address']['streetAddress'])) {
                        $parts = array('streetNumber', 'streetDirection', 'streetName', 'streetType');
                        $sa = array();
                        foreach ($parts as $key) {
                            if (isset($result['subscribers'][$i]['address'][$key])) {
                                $sa[] = $result['subscribers'][$i]['address'][$key];
                            }
                        }
                        $result['subscribers'][$i]['address']['streetAddress'] = implode(" ", $sa);
                        $result['subscribers'][$i]['address']['addressLine2'] = '';
                    }
                }
            }
        }
		return $result;
    }

    /**
     * Add a new subscriber to the database
     *
     * @param array $subscriber_info {
     *      @var string $firstName Subscriber's first name
     *      @var string $lastName Subscriber's last name
     *      @var array $address {
     *           @var string $streetAddress First line of subscriber's address
     *              @var string $addressLine2 Second line of subscriber's address (optional)
     *              @var string $city Subscriber's city
     *              @var string $state Subscriber's state
     *              @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
     *      }
     *      @var string $email Email address for the subscriber (optional)
     *      @var string $contactNumber Contact phone number for the subscriber (optional)
     * }
     */
    public function addSubscriber($subscriber_info) {
        $url = $this->base_url . 'accounts?MVNO=' .$this->mvno;
        $ch = $this->getChannel();

        $json_payload = json_encode($subscriber_info);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($json_payload))
        );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }

    /**
     * Update subscriber details
     *
     * @param string $accountNumber Account number of the subscriber to update
     * @param array $subscriber_info {
     *      @var string $firstName Subscriber's first name
     *      @var string $lastName Subscriber's last name
     *      @var array $address {
     *          @var string $streetAddress First line of subscriber's address
     *          @var string $addressLine2 Second line of subscriber's address (optional)
     *          @var string $city Subscriber's city
     *          @var string $state Subscriber's state
     *          @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
     *      }
     *      @var string $email Email address for the subscriber (optional)
     *      @var string $contactNumber Contact phone number for the subscriber (optional)
     * }
     */
    public function patchSubscriber($accountNumber, $subscriber_info) {
        $url = $this->base_url . 'accounts/'.$accountNumber.'?type=accountnumber&MVNO=' .$this->mvno;
        $ch = $this->getChannel();
        $json_payload = json_encode($subscriber_info);

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($json_payload))
        );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }

    private function _activation($subscriber, $service, $portinfo = NULL, $operationId = NULL, $callbackUrl = NULL, $method = 'POST') {
        $url = $this->base_url . 'activations?MVNO=' . $this->mvno;
        $ch = $this->getChannel();

        // Convert the characteristics
        $characteristics = array();
        foreach ($service['characteristics'] as $name => $value) {
            $characteristics[] = array("name" => $name, "value" => $value);
        }

        // replace the characteristics in the service info
        $service['characteristics'] = $characteristics;

        $payload = array(
            'activations' => array(
                array(
                    'subscriber' => $subscriber,
                    'service' => $service
                )
            )
        );

        if (isset($operationId)) {
            $payload['activations'][0]['operation_id'] = intval($operationId);
        }

        if (isset($callbackUrl)) {
            $payload['callbackUrl'] = $callbackUrl;
        }

        if (isset($portinfo)) {
            if (isset($operationId)) {
                $portinfo['operation_id'] = intval($operationId);
            }
            $payload['activations'][0]['portInInfo'] = $portinfo;
        }

        $json_payload = json_encode($payload);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($json_payload))
        );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }

    /**
     * Add a new subscription, activating service
     *
     * @param array $subscriber {
     *      @var string $firstName Subscriber's first name
     *      @var string $lastName Subscriber's last name
     *      @var array $address {
     *          @var string $streetAddress First line of subscriber's address
     *          @var string $addressLine2 Second line of subscriber's address (optional)
     *          @var string $city Subscriber's city
     *          @var string $state Subscriber's state
     *          @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
     *      }
     *      @var string $email Email address for the subscriber (optional)
     *      @var string $contactNumber Contact phone number for the subscriber (optional)
     *      @var int $subscriberId Account number of the subscriber to connect this subscription to
     * }
     * @param array $service {
     *      @var array characteristics {}
     *          @var string $serviceZipCode
     *          @var string IMEI
     *          @var string ICCID
     *          @var string planName
     *          @var string serviceType
     *          @var string size
     *          @var string tethering Tethering enabled/disable ("Yes"/"No")
     *          @var string intlCalling International calling allowed ("Yes"/"No")
     *          @var string intlRoaming International roaming allowed ("Yes"/"No")
     *          @var string <feature name> Other supported features (optional)
     *      }
     *      @var string phoneNumber Phone number to activate service on (optional)
     * }
     * @param int @operationId Operation ID if resubmitting (optional)
     * @param string @callbackUrl Callback URL to add to the request (optional)
     *
     */
     public function addSubscription($subscriber, $service, $operationId = NULL, $callbackUrl = NULL) {
         return $this->_activation($subscriber, $service, NULL, $operationId, $callbackUrl);
     }

     /**
      * Add a new subscription, activating service and porting a number
      *
      * @param array $subscriber {
      *      @var string $firstName Subscriber's first name
      *      @var string $lastName Subscriber's last name
      *      @var array $address {
      *          @var string $streetAddress First line of subscriber's address
      *          @var string $addressLine2 Second line of subscriber's address (optional)
      *          @var string $city Subscriber's city
      *          @var string $state Subscriber's state
      *          @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
      *      }
      *      @var string $email Email address for the subscriber (optional)
      *      @var string $contactNumber Contact phone number for the subscriber (optional)
      *      @var int $subscriberId Account number of the subscriber to connect this subscription to
      * }
      * @param array $service {
      *      @var array characteristics {}
      *          @var string $serviceZipCode
      *          @var string IMEI
      *          @var string ICCID
      *          @var string planName
      *          @var string serviceType
      *          @var string size
      *          @var string tethering Tethering enabled/disable ("Yes"/"No")
      *          @var string intlCalling International calling allowed ("Yes"/"No")
      *          @var string intlRoaming International roaming allowed ("Yes"/"No")
      *          @var string <feature name> Other supported features (optional)
      *      }
      *      @var string phoneNumber Phone number to activate service on (optional)
      * }
      * @param array $portinfo { (optional)
      *      @var int $subscriberId
      *      @var string $phoneNumber
      *      @var string $serviceZipCode
      *      @var strring $portRequestLineId Phone number to port
      *      @var array $authorizer {
      *          @var string $firstName
      *          @var string $lastName
      *          @var array $address {
      *              @var string $streetAddress
      *              @var string $city
      *              @var string $state
      *              @var string $zipCode
      *          }
      *      }
      *      @var array $serviceInfo {
      *          @var string $area
      *      }
      *      @var array $oldServiceProvider {
      *          @var string $accountNumber
      *          @var string $password
      *          @var string firstName
      *          @var string $lastName
      *      }
      * }
      * @param int @operationId Operation ID if resubmitting (optional)
      * @param string @callbackUrl Callback URL to add to the request (optional)
      *
      */
     public function addPortSubscription($subscriber, $service, $portinfo, $operationId = NULL, $callbackUrl = NULL) {
         return $this->_activation($subscriber, $service, $portinfo, $operationId, $callbackUrl);
     }

    /**
     * Patch an existing subscription request that is porting a number
     *
     * @param array $subscriber {
     *      @var string $firstName Subscriber's first name
     *      @var string $lastName Subscriber's last name
     *      @var array $address {
     *          @var string $streetAddress First line of subscriber's address
     *          @var string $addressLine2 Second line of subscriber's address (optional)
     *          @var string $city Subscriber's city
     *          @var string $state Subscriber's state
     *          @var string $zipCode Subscriber's ZIP code (US: 5 digit only)
     *      }
     *      @var string $email Email address for the subscriber (optional)
     *      @var string $contactNumber Contact phone number for the subscriber (optional)
     *      @var int $subscriberId Account number of the subscriber to connect this subscription to
     * }
     * @param array $service {
     *      @var array characteristics {}
     *          @var string $serviceZipCode
     *          @var string IMEI
     *          @var string ICCID
     *          @var string planName
     *          @var string serviceType
     *          @var string size
     *          @var string tethering Tethering enabled/disable ("Yes"/"No")
     *          @var string intlCalling International calling allowed ("Yes"/"No")
     *          @var string intlRoaming International roaming allowed ("Yes"/"No")
     *          @var string <feature name> Other supported features (optional)
     *      }
     *      @var string phoneNumber Phone number to activate service on (optional)
     * }
     * @param array $portinfo {
     *      @var int $subscriberId
     *      @var string $phoneNumber
     *      @var string $serviceZipCode
     *      @var strring $portRequestLineId Phone number to port
     *      @var array $authorizer {
     *          @var string $firstName
     *          @var string $lastName
     *          @var array $address {
     *              @var string $streetAddress
     *              @var string $city
     *              @var string $state
     *              @var string $zipCode
     *          }
     *      }
     *      @var array $serviceInfo {
     *          @var string $area
     *      }
     *      @var array $oldServiceProvider {
     *          @var string $accountNumber
     *          @var string $password
     *          @var string firstName
     *          @var string $lastName
     *      }
     * }
     * @param string @callbackUrl Callback URL to add to the request (optional)
     *
     */
    public function patchPortSubscription($subscriber, $service, $portinfo, $operationId = NULL, $callbackUrl = NULL) {
        return $this->_activation($subscriber, $service, $portinfo, $operationId, $callbackUrl, 'PATCH');
    }

    /**
     * Get information about an activation that is pending
     *
     * @param string $activationId The AT&T activation ID to query
     * @return array (
     *      @var int resultCode
     *      @var string resultType
     *      @var array messages
     *      @var array results (
     *          @var string status
     *          @var string id
     *          @var string number
     *      )
     * }
     */
    public function getActivation($activationId) {
        $url = $this->base_url . 'activations/' . $activationId . '?MVNO=' . $this->mvno;
        $ch = $this->getChannel();

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }


    /**
     *
     * @param string $phoneNumber The phone number to query the service details for
     * @return array {
     *      @var string resultType Success or failure
     *      @var int resultCode Success (zero) or failure (non-zero)
     *      @var array messages List of messages (incl. error messages)
     *      @var string status Line status
     *      @var string billingAccountNumber AT&T BAN
     *      @var int subscriberId The subscriber record associated with the subscription
     *      @var array characteristics List of line characteristics (each entry itself an array with name & value as keys)
     *      @var array usage {
     *          @var array DATA {
     *              @var float Home
     *              @var float Roaming
     *              @var float Hotspot
     *              @var float Broadband
     *          }
     *          @var array VOICE {
     *              @var float Home
     *              @var float Roaming
     *              @var float International
     *          }
     *          @var array SMS {
     *              @var float Home
     *              @var float Roaming
     *              @var float International
     *          }
     *          @var array MMS {
     *              @var float Home
     *              @var float Roaming
     *              @var float International
     *          }
     *      }
     * }
     */
    public function getServices($phoneNumber) {
        $ch = $this->getChannel();
        $url = $this->base_url . 'services/'.$phoneNumber.'?MVNO=' . $this->mvno;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }

    /**
     * Get usage information
     *
     * @param string $phoneNumber Phone number to query
     * @param string $fromDate Date to start from (YYYY-MM-DD)
     * @param string $toDate Date to end at (YYYY-MM-DD)
     *
     * @return array {
     *      @var string resultType Success or failure
     *      @var int resultCode Success (zero) or failure (non-zero)
     *      @var array messages List of messages (incl. error messages)
     *      @var array usages {
     *          array {
     *              @var string from
     *              @var string to
     *              @var string date
     *              @var float duration
     *              @var int amount
     *              @var string serviceType
     *          }
     *      }
     * }
     */
    public function getUsage($phoneNumber, $fromDate, $toDate) {
        $ch = $this->getChannel();
        $url = $this->base_url . 'usage/?MVNO=' .$this->mvno .'&msisdn='.$phoneNumber.'&fromDate='.$fromDate.'&toDate='.$toDate;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }

    /**
     * Get the status of a number port
     *
     * @param string $phoneNumber The phone number being ported
     *
     * @return array {
     *    @var int resultCode
     *    @var string resultType
     *    @var string statusReasonCode
     *    @var string statusReasonDescription
     *    @var array messages []
     * }
     *
     */
    public function getPortinStatus($phoneNumber) {
      $ch = $this->getChannel();
      $url = $this->base_url . 'portin/' . $phoneNumber .'?MVNO=' .$this->mvno;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
      $result = curl_exec($ch);
      curl_close($ch);
      return json_decode($result, true);
    }

    /**
     * Cancel a port in progress
     *
     * @param string $phoneNumber The number being ported
     * @param string $zipCode The service ZIP code
     *
     * @return array {
     *    @var int resultCode
     *    @var string resultType
     *    @var array messages []
     * }
     *
     */
    public function cancelPortin($phoneNumber, $zipCode) {
      $ch = $this->getChannel();
      $url = $this->base_url . 'portin/' . $phoneNumber .'?MVNO=' .$this->mvno . '&zipCode=' . $zipCode;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
      $result = curl_exec($ch);
      curl_close($ch);
      return json_decode($result, true);
    }

    /*

    TODO

    public function getactivationPorts()
    {
        $this->load->helper('api_helper');
        $this->APIDetails = getAPIBaseURLcURLMVNO($this->session->cid);
        $ch = $this->APIDetails['ch'];
        $MVNO = $this->APIDetails['MVNO'];
        $query = '';
        $sort = '';
        $order = '';
        $APIBaseURL = $this->APIDetails['APIBaseURL'];
        $url = $APIBaseURL . 'portin/list/?offset=0&limit=30&query=&sort=&order=&MVNO='.$MVNO;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        $result = json_decode($result, true);
        return $result;

    }

    public function getActivationPortsDetails($operationId)
    {
        $this->load->helper('api_helper');
        $this->APIDetails = getAPIBaseURLcURLMVNO($this->session->cid);
        $ch = $this->APIDetails['ch'];
        $MVNO = $this->APIDetails['MVNO'];
        $APIBaseURL = $this->APIDetails['APIBaseURL'];
        $url = $APIBaseURL . 'operations/'.$operationId.'?MVNO=' .$this->APIDetails['MVNO'];
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
        $result = json_decode($result, true);
        return $result;
    }

    */

    /**
     *
     * @param string $imei The IMEI to lookup
     * @return array {
     *      @var string resultType Success or failure
     *      @var int resultCode Success (zero) or failure (non-zero)
     *      @var array messages List of messages (incl. error messages)
     *      @var string manufacturer
     *      @var string networkType
     *      @var string imeiType
     *      @var string model
     *      @var array plans {
     *          @var array {
     *              @var string plan e.g. Mobile Select
     *              @var string tethering Yes/No
     *              @var string type 'Data and Voice' or 'Data Only'
     *              @var string size e.g. 1GB, Unlimited Starter
     *          },
     *          ...
     *      }
     * }
     */
    public function getDeviceInfo($imei) {
        $ch = $this->getChannel();
        $url = $this->base_url . 'devices/'.$imei.'?MVNO=' . $this->mvno;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result);
    }

};
