<?php
/**
 * Settings for the Pareteum plugin
 */


class TeumSettings {
	protected $action    	 = 'convert_skus';

	public function __construct() {
		add_action('admin_menu', array($this, 'add_settings_page'));
		add_action('admin_init', array($this, 'mobility_settings_init'));
		add_action("admin_post_$this->action", array ($this, 'admin_post'));
	}

	/*
	 * Add a settings page
	 */
	function add_settings_page() {
		add_menu_page('Pareteum Settings',
			      'Pareteum',
			      'administrator',
			      'pareteum',
			      array($this, 'render_settings_page'));
	}

	/*
	 * Render the page
	 */
	function render_settings_page() {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	    ?>
	    <form action="options.php" method="post">
			<?php
				settings_fields( 'pareteum' );
				do_settings_sections( 'pareteum' );
				submit_button( 'Save' );
			?>
	    </form>
		<?php
			$posts = $this->_getPostsWithoutSkuAttribute();
			if (!empty($posts)) {
				?>
				<h3>Convert SKUs to Attributes</h3>
				<form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="POST">
					<input type="hidden" name="action" value="<?php echo $this->action; ?>" />
					<?php wp_nonce_field($this->action, $this->action . '_nonce', FALSE ); ?>
					<input type="hidden" name="_wp_http_referer" value="<?php echo $redirect; ?>" />
					<?php submit_button( 'Convert' ); ?>
				</form>
				<?php
			}
	}

	function mobility_settings_init() {

	    register_setting( 'pareteum', 'pareteum_mobility_options' );

	    add_settings_section(
			'pareteum_mobility',
			'Mobility API Settings',
			array($this, 'mobility_info_render'),
			'pareteum'
		);

		add_settings_field(
			'teum_mobility_api_selector',
			'Production/Sandbox',
			array($this, 'mobility_api_selector_render'),
			'pareteum',
			'pareteum_mobility'
		);

	    add_settings_field(
			'teum_mobility_mvnoid',
			'MVNO ID',
			array($this, 'mobility_mvnoid_render'),
			'pareteum',
			'pareteum_mobility'
	    );

	    add_settings_field(
			'teum_mobility_api_username',
			'API Username',
			array($this, 'mobility_api_user_render'),
			'pareteum',
			'pareteum_mobility'
	    );
	    add_settings_field(
			'teum_mobility_api_password',
			'API Password',
			array($this, 'mobility_api_pass_render'),
			'pareteum',
			'pareteum_mobility'
	    );

		// Sandbox API settings
		add_settings_field(
			'teum_mobility_sandbox_mvnoid',
			'Sandbox MVNO ID',
			array($this, 'mobility_sandbox_mvnoid_render'),
			'pareteum',
			'pareteum_mobility'
	    );

	    add_settings_field(
			'teum_mobility_sandbox_username',
			'Sandbox Username',
			array($this, 'mobility_sandbox_user_render'),
			'pareteum',
			'pareteum_mobility'
	    );
	    add_settings_field(
			'teum_mobility_sandbox_password',
			'Sandbox Password',
			array($this, 'mobility_sandbox_pass_render'),
			'pareteum',
			'pareteum_mobility'
	    );

		// add_settings_field(
		// 	'teum_mobility_sku_convert',
		// 	'Convert SKUs',
		// 	array($this, 'mobility_sku_convert_render'),
		// 	'pareteum',
		// 	'pareteum_mobility'
		// );
	}

	function mobility_info_render() {
	}

	function mobility_mvnoid_render() {
	    $options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('mvno_id', $options)) {
			$options['mvno_id'] = '';
		}
	    echo "<input id='teum_mobility_mvnoid' name='pareteum_mobility_options[mvno_id]' type='text' value='" . esc_attr( $options['mvno_id'] ). "' />";
	}

	function mobility_api_user_render() {
	    $options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('api_username', $options)) {
			$options['api_username'] = '';
		}
	    echo "<input id='teum_mobility_api_username' name='pareteum_mobility_options[api_username]' type='text' value='" . esc_attr( $options['api_username'] ) . "' />";
	}

	function mobility_api_pass_render() {
	    $options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('api_password', $options)) {
			$options['api_password'] = '';
		}
	    echo "<input id='teum_mobility_api_password' name='pareteum_mobility_options[api_password]' type='text' value='" . esc_attr( $options['api_password'] ) . "' />";
	}

	function mobility_sandbox_mvnoid_render() {
		$options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('sandbox_mvno_id', $options)) {
			$options['sandbox_mvno_id'] = '1234';
		}
		echo "<input id='teum_mobility_sandbox_mvnoid' name='pareteum_mobility_options[sandbox_mvno_id]' type='text' value='" . esc_attr( $options['sandbox_mvno_id'] ). "' />";
	}

	function mobility_sandbox_user_render() {
		$options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('sandbox_username', $options)) {
			$options['sandbox_username'] = 'team_qa';
		}
		echo "<input id='teum_mobility_sandbox_username' name='pareteum_mobility_options[sandbox_username]' type='text' value='" . esc_attr( $options['sandbox_username'] ) . "' />";
	}

	function mobility_sandbox_pass_render() {
		$options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('sandbox_password', $options)) {
			$options['sandbox_password'] = '';
		}
		echo "<input id='teum_mobility_sandbox_password' name='pareteum_mobility_options[sandbox_password]' type='text' value='" . esc_attr( $options['sandbox_password'] ) . "' />";
	}

	function mobility_api_selector_render() {
		$options = get_option( 'pareteum_mobility_options' );
		if (!array_key_exists('api_selector', $options)) {
			$options['api_selector'] = 'sandbox';
		}
		echo "<input type='radio' name='pareteum_mobility_options[api_selector]' value='production' " . checked('production', $options['api_selector'], false) . "/>&nbsp;Production&nbsp;";
		echo "<input type='radio' name='pareteum_mobility_options[api_selector]' value='sandbox' " . checked('sandbox', $options['api_selector'], false) . "/>&nbsp;Sandbox";
	}

	// function mobility_sku_convert_render() {
	// 	// This one does not save; if it is checked on save it does the work, then clears
	// 	echo "<input type='checkbox' name='pareteum_mobility_options[sku_convert]' value='convert'/>";
	// }


	private function _getPostsWithoutSkuAttribute() {
		$results = array();

		$posts = get_posts( array(
			'post_type' => 'product',
			'numberposts' => -1,
			'post_status' => 'publish',
			'tax_query' => array(
				array(
					'taxonomy' => 'product_cat',
					'field' => 'slug',
					'terms' => 'Plans', /*category name*/
					'operator' => 'IN',
					)
				),
			));

		foreach($posts as $p) {
			$prod = wc_get_product($p->ID);
			$teum_sku = $prod->get_attribute('pareteum_sku');
			if (empty($teum_sku)) {
				$results[] = $p;
			}
		}
		return $results;
	}

	public function admin_post() {
		error_log("TeumSettings::admin_post");

		if (!wp_verify_nonce($_POST[$this->action . '_nonce'], $this->action)) {
			error_log($this->action . " => Invalid nonce");
			die('Invalid nonce.' . var_export($_POST, true));
		}


		if (isset($_POST['action'])) {
			error_log("Action: " . $_POST['action']);
			$posts = $this->_getPostsWithoutSkuAttribute();

			foreach($posts as $p) {
				$prod = wc_get_product($p->ID);
				$sku = $prod->get_sku();
				if (!empty($sku)) {
					$attribute_sku = str_replace("|", ":", $sku);
					error_log("Updating ".$p->ID." with ".$attribute_sku);

					$attr = array(
							"name" => "pareteum_sku",
							"value" => $attribute_sku,
							"posiion" => 1,
							"is_visible" => 1,
							"is_variation" => 0,
							"is_taxonomy" => 0
					);
					$attrs = array( 'pareteum_sku' => $attr);
					error_log("After: ".print_r($attrs, true));
					update_post_meta( $p->ID, '_product_attributes', $attrs);
				}
			}
		} else {
			error_log("TeumSettings => Action not set?");
		}

		if (!isset($_POST['_wp_http_referer'])) {
		 	die( 'Missing target.' );
		}
		wp_safe_redirect(urldecode($_POST['_wp_http_referer']));
	}
};
